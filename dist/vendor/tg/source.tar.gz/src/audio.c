/*
    tg
    Copyright (C) 2015 Marcello Mamino

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License version 2 as
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "tg.h"
#include <portaudio.h>

/* Huge buffer of audio */
float pa_buffers[PA_BUFF_SIZE];
int write_pointer = 0;
uint64_t timestamp = 0;
pthread_mutex_t audio_mutex;
static PaDeviceIndex selected_input_device = paNoDevice;
static int selected_sample_rate = PA_SAMPLE_RATE;

/* Data for PA callback to use */
static struct callback_info {
	int 	channels;	//!< Number of channels
	bool	light;		//!< Light algorithm in use, copy half data
} info;

static int paudio_callback(const void *input_buffer,
			   void *output_buffer,
			   unsigned long frame_count,
			   const PaStreamCallbackTimeInfo *time_info,
			   PaStreamCallbackFlags status_flags,
			   void *data)
{
	UNUSED(output_buffer);
	UNUSED(time_info);
	UNUSED(status_flags);
	const float *input_samples = (const float*)input_buffer;
	unsigned long i;
	const struct callback_info *info = data;
	unsigned wp = write_pointer;

	if (info->light) {
		static bool even = true;
		/* Copy every other sample.  It would be much more efficient to
		 * just drop the sample rate if the sound hardware supports it.
		 * This would also avoid the aliasing effects that this simple
		 * decimation without a low-pass filter causes.  */
		if(info->channels == 1) {
			for(i = even ? 0 : 1; i < frame_count; i += 2) {
				pa_buffers[wp++] = input_samples[i];
				if (wp >= PA_BUFF_SIZE) wp -= PA_BUFF_SIZE;
			}
		} else {
			for(i = even ? 0 : 2; i < frame_count*2; i += 4) {
				pa_buffers[wp++] = input_samples[i] + input_samples[i+1];
				if (wp >= PA_BUFF_SIZE) wp -= PA_BUFF_SIZE;
			}
		}
		/* Keep track if we have processed an even number of frames, so
		 * we know if we should drop the 1st or 2nd frame next callback. */
		if(frame_count % 2) even = !even;
	} else {
		const unsigned len = MIN(frame_count, PA_BUFF_SIZE - wp);
		if(info->channels == 1) {
			memcpy(pa_buffers + wp, input_samples, len * sizeof(*pa_buffers));
			if(len < frame_count)
				memcpy(pa_buffers, input_samples + len, (frame_count - len) * sizeof(*pa_buffers));
		} else {
			for(i = 0; i < len; i++)
				pa_buffers[wp + i] = input_samples[2u*i] + input_samples[2u*i + 1u];
			if(len < frame_count)
				for(i = len; i < frame_count; i++)
					pa_buffers[i - len] = input_samples[2u*i] + input_samples[2u*i + 1u];
		}
		wp = (wp + frame_count) % PA_BUFF_SIZE;
	}
	pthread_mutex_lock(&audio_mutex);
	write_pointer = wp;
	timestamp += frame_count;
	pthread_mutex_unlock(&audio_mutex);
	return 0;
}

int start_portaudio(int *nominal_sample_rate, double *real_sample_rate)
{
	PaStream *stream;

	if(pthread_mutex_init(&audio_mutex,NULL)) {
		error("Failed to setup audio mutex");
		return 1;
	}

	PaError err = Pa_Initialize();
	if(err!=paNoError)
		goto error;

#ifdef DEBUG
	if(testing) {
		*nominal_sample_rate = selected_sample_rate;
		*real_sample_rate = selected_sample_rate;
		goto end;
	}
#endif

	PaDeviceIndex default_input = Pa_GetDefaultInputDevice();
	if(default_input == paNoDevice) {
		error("No default audio input device found");
		return 1;
	}

	PaDeviceIndex input_device = default_input;
	if(selected_input_device != paNoDevice) {
		const PaDeviceInfo *selected_info = Pa_GetDeviceInfo(selected_input_device);
		if(selected_info && selected_info->maxInputChannels > 0)
			input_device = selected_input_device;
		else
			debug("Selected audio device %d is not usable, falling back to default\n", (int)selected_input_device);
	}

	const PaDeviceInfo *input_info = Pa_GetDeviceInfo(input_device);
	if(!input_info) {
		error("Unable to query selected audio input device");
		return 1;
	}

	long channels = input_info->maxInputChannels;
	if(channels == 0) {
		error("Selected audio device has no input channels");
		return 1;
	}
	if(channels > 2) channels = 2;
	info.channels = channels;
	info.light = false;

	PaStreamParameters input_parameters;
	input_parameters.device = input_device;
	input_parameters.channelCount = (int)channels;
	input_parameters.sampleFormat = paFloat32;
	input_parameters.suggestedLatency = input_info->defaultLowInputLatency;
	input_parameters.hostApiSpecificStreamInfo = NULL;

	err = Pa_OpenStream(&stream,&input_parameters,NULL,selected_sample_rate,paFramesPerBufferUnspecified,paNoFlag,paudio_callback,&info);
	if(err!=paNoError) {
		/* If opening the chosen device failed, try to find a fallback:
		 * - On Linux with JACK running, the ALSA device may be locked;
		 *   scan for a JACK host API device and retry.
		 * - On macOS, CoreAudio may fail if permissions aren't granted;
		 *   surface a specific diagnostic and fall through to the error. */
		const PaDeviceInfo *failed_info = Pa_GetDeviceInfo(input_device);
		PaHostApiIndex failed_host = failed_info ? failed_info->hostApi : -1;
		const PaHostApiInfo *failed_api = (failed_host >= 0) ? Pa_GetHostApiInfo(failed_host) : NULL;
		const char *failed_api_name = failed_api ? failed_api->name : "unknown";

		debug("Pa_OpenStream failed on host API '%s': %s\n", failed_api_name, Pa_GetErrorText(err));

		/* Try JACK fallback if ALSA device failed */
		PaHostApiIndex jack_api = Pa_HostApiTypeIdToHostApiIndex(paJACK);
		if(jack_api >= 0 && failed_api && failed_api->type == paALSA) {
			const PaHostApiInfo *jack_info = Pa_GetHostApiInfo(jack_api);
			if(jack_info && jack_info->defaultInputDevice != paNoDevice) {
				PaDeviceIndex jack_device = jack_info->defaultInputDevice;
				const PaDeviceInfo *jdi = Pa_GetDeviceInfo(jack_device);
				if(jdi && jdi->maxInputChannels > 0) {
					debug("ALSA device failed; retrying with JACK device %d\n", (int)jack_device);
					long jchannels = jdi->maxInputChannels > 2 ? 2 : jdi->maxInputChannels;
					info.channels = (int)jchannels;
					PaStreamParameters jp;
					jp.device = jack_device;
					jp.channelCount = (int)jchannels;
					jp.sampleFormat = paFloat32;
					jp.suggestedLatency = jdi->defaultLowInputLatency;
					jp.hostApiSpecificStreamInfo = NULL;
					PaError jerr = Pa_OpenStream(&stream,&jp,NULL,selected_sample_rate,paFramesPerBufferUnspecified,paNoFlag,paudio_callback,&info);
					if(jerr == paNoError) {
						input_device = jack_device;
						err = paNoError;
					} else {
						debug("JACK fallback also failed: %s\n", Pa_GetErrorText(jerr));
						/* Restore info.channels for the primary error path */
						info.channels = (int)channels;
					}
				}
			}
		}

		if(err != paNoError) {
			/* Emit platform-specific hint before the generic error */
			if(failed_api && failed_api->type == paALSA)
				error("Audio device is busy. If JACK (jackd/PipeWire-JACK) is running, "
				      "try selecting the JACK input device from the device list or stop JACK first.");
#ifdef __APPLE__
			if(failed_api && failed_api->type == paCoreAudio)
				error("Could not open audio input on macOS. Check System Settings > "
				      "Privacy & Security > Microphone and allow access for this application.");
#endif
			goto error;
		}
	}

	err = Pa_StartStream(stream);
	if(err!=paNoError)
		goto error;

	const PaStreamInfo *info = Pa_GetStreamInfo(stream);
	*nominal_sample_rate = selected_sample_rate;
	*real_sample_rate = info->sampleRate;
	selected_input_device = input_device;
#ifdef DEBUG
end:
#endif
	debug("sample rate: nominal = %d real = %f\n",*nominal_sample_rate,*real_sample_rate);

	return 0;

error:
	error("Error opening audio input: %s", Pa_GetErrorText(err));
	return 1;
}

int list_audio_input_devices(int **devices, char ***names, int *count, int *default_device)
{
	if(!devices || !names || !count || !default_device)
		return 1;

	*devices = NULL;
	*names = NULL;
	*count = 0;
	*default_device = (int)Pa_GetDefaultInputDevice();

	int ndevices = Pa_GetDeviceCount();
	if(ndevices < 0)
		return 1;

	int *devs = malloc(ndevices * sizeof(*devs));
	char **dev_names = malloc(ndevices * sizeof(*dev_names));
	if(!devs || !dev_names) {
		free(devs);
		free(dev_names);
		return 1;
	}

	int used = 0;
	for(int i = 0; i < ndevices; i++) {
		const PaDeviceInfo *di = Pa_GetDeviceInfo((PaDeviceIndex)i);
		if(!di || di->maxInputChannels <= 0)
			continue;

		devs[used] = i;
		dev_names[used] = strdup(di->name ? di->name : "Unknown device");
		if(!dev_names[used]) {
			for(int j = 0; j < used; j++)
				free(dev_names[j]);
			free(devs);
			free(dev_names);
			return 1;
		}
		used++;
	}

	if(!used) {
		free(devs);
		free(dev_names);
		return 1;
	}

	*devices = devs;
	*names = dev_names;
	*count = used;
	return 0;
}

void free_audio_input_devices(int *devices, char **names, int count)
{
	for(int i = 0; i < count; i++)
		free(names[i]);
	free(names);
	free(devices);
}

void set_audio_input_device(int device)
{
	selected_input_device = device >= 0 ? (PaDeviceIndex)device : paNoDevice;
}

int get_audio_input_device(void)
{
	return selected_input_device == paNoDevice ? AUDIO_DEVICE_DEFAULT : (int)selected_input_device;
}

void set_audio_sample_rate(int sample_rate)
{
	if(sample_rate > 0)
		selected_sample_rate = sample_rate;
}

int get_audio_sample_rate(void)
{
	return selected_sample_rate;
}

int terminate_portaudio()
{
	debug("Closing portaudio\n");
	PaError err = Pa_Terminate();
	if(err != paNoError) {
		error("Error closing audio: %s", Pa_GetErrorText(err));
		return 1;
	}
	return 0;
}

uint64_t get_timestamp(int light)
{
	pthread_mutex_lock(&audio_mutex);
	uint64_t ts = light ? timestamp / 2 : timestamp;
	pthread_mutex_unlock(&audio_mutex);
	return ts;
}

static void fill_buffers(struct processing_buffers *ps, int light)
{
	pthread_mutex_lock(&audio_mutex);
	uint64_t ts = timestamp;
	int wp = write_pointer;
	pthread_mutex_unlock(&audio_mutex);

	if(light)
		ts /= 2;

	int i;
	for(i = 0; i < NSTEPS; i++) {
		ps[i].timestamp = ts;

		int start = wp - ps[i].sample_count;
		if (start < 0) start += PA_BUFF_SIZE;
		int len = MIN((unsigned)ps[i].sample_count, PA_BUFF_SIZE - start);
		memcpy(ps[i].samples, pa_buffers + start, len * sizeof(*pa_buffers));
		if (len < ps[i].sample_count)
			memcpy(ps[i].samples + len, pa_buffers, (ps[i].sample_count - len) * sizeof(*pa_buffers));
	}
}

int analyze_pa_data(struct processing_data *pd, int bph, double la, uint64_t events_from)
{
	struct processing_buffers *p = pd->buffers;
	fill_buffers(p, pd->is_light);

	int i;
	debug("\nSTART OF COMPUTATION CYCLE\n\n");
	for(i=0; i<NSTEPS; i++) {
		p[i].last_tic = pd->last_tic;
		p[i].events_from = events_from;
		process(&p[i], bph, la, pd->is_light);
		if( !p[i].ready ) break;
		debug("step %d : %f +- %f\n",i,p[i].period/p[i].sample_rate,p[i].sigma/p[i].sample_rate);
	}
	if(i) {
		pd->last_tic = p[i-1].last_tic;
		debug("%f +- %f\n",p[i-1].period/p[i-1].sample_rate,p[i-1].sigma/p[i-1].sample_rate);
	} else
		debug("---\n");
	return i;
}

int analyze_pa_data_cal(struct processing_data *pd, struct calibration_data *cd)
{
	struct processing_buffers *p = pd->buffers;
	fill_buffers(p, pd->is_light);

	int i,j;
	debug("\nSTART OF CALIBRATION CYCLE\n\n");
	for(j=0; p[j].sample_count < 2*p[j].sample_rate; j++);
	for(i=0; i+j<NSTEPS-1; i++)
		if(test_cal(&p[i+j]))
			return i ? i+j : 0;
	if(process_cal(&p[NSTEPS-1], cd))
		return NSTEPS-1;
	return NSTEPS;
}

/** Change to light mode
 *
 * Call to enable or disable light mode.  Changing the mode will empty the audio
 * buffer.  Nothing will happen if the mode doesn't actually change.
 *
 * @param light True for light mode, false for normal
 */
void set_audio_light(bool light)
{
	if(info.light != light) {
		pthread_mutex_lock(&audio_mutex);
		info.light = light;
		memset(pa_buffers, 0, sizeof(pa_buffers));
		write_pointer = 0;
		timestamp = 0;
		pthread_mutex_unlock(&audio_mutex);
	}
}
