# MAC Bespoke Web Timegrapher

A browser-based timegrapher for mechanical watches. Listens to a movement's
escapement through an audio input and measures rate, amplitude, beat error and
beat frequency. Public GPLv2 fork of [`agrigera/tg`](https://github.com/agrigera/tg),
a native GTK desktop application.

- **Repo:** https://github.com/natemac/mac-timegrapher (public)
- **Live:** https://macwatches.com/tools/timegrapher/
- **Roadmap:** `docs/roadmap.md`. Milestones 1-3 shipped (foundation, DSP core,
  WebAssembly). The app measures live, with movement presets, multi-position
  sessions and PWA install.

## Licensing — read before adding anything

The upstream headers say "version 2 as published by the Free Software
Foundation" with **no "or later" clause**. This is **GPLv2-only**.

- Never write "or later". Never add a GPLv3-only dependency.
- **Every new source file gets the GPLv2 header** — `.ts`, `.tsx`, `.js`, `.css`,
  `.html`, and **test files too**. Copy the block verbatim from `web/src/App.tsx`.
- `LICENSE` must stay byte-identical to upstream. Never edit it.
- The in-app "Open source (GPLv2) — view source" link in `SourceFooter.tsx` is a
  legal obligation, not decoration. Serving WASM/JS to a browser is distribution
  under §3. Since the v36 interface it sits in the page footer (`AppFooter.tsx`),
  which renders on every screen — the opening screen and both measuring modes —
  and it must never be behind a condition, a setting or a tab.
  `docs/deployment.md` blocks the deploy if it is missing from the built bundle.
- Business logic — build numbers, customer records, inventory, pricing, QC
  thresholds — belongs in the private PHP app at `macwatches.com`, never here.
  The two talk only over authenticated HTTP. `docs/build-plan.md` was purged from
  history for violating this; don't reintroduce that kind of content.

## Audio constraints that are not negotiable

These decide whether measurements mean anything. All are in
`web/src/audio/audio-engine.ts`.

- **`echoCancellation`, `autoGainControl`, `noiseSuppression` must all be
  `false`.** Browsers enable them by default. AGC continuously rescales the
  signal and amplitude is derived from impulse energy — AGC doesn't degrade the
  measurement, it *invalidates* it. Noise suppression is tuned for speech and
  treats watch ticks as noise to remove.
- **Construct `AudioContext` at the device's reported `sampleRate`.** Omitting it
  defaults to the system rate and silently resamples. A resampled fixture looks
  perfectly valid and poisons every downstream comparison.
- **`checkAppliedProcessing` is three-state** (`applied` / `unreported`). Safari
  omits `autoGainControl` from `getSettings()`, so "off" and "unknown" are not
  the same thing and must not render the same.
- **Fixtures are 32-bit IEEE float**, never 16-bit PCM — quantisation would be
  permanent. `audio/wav.ts` encodes them and `tools/make-synthetic-fixture.mjs`
  generates one with an exactly known beat period, which is how the DSP is
  checked against ground truth rather than against a plausible-looking number.
- **The worklet node routes to a destination through a muted gain node.** A
  worklet is only pulled when its output reaches one — at zero gain, so the
  watch isn't played out the speakers. Which destination is not free on
  Android: reaching `ctx.destination` opens a hardware output stream, and the
  platform re-pairs the communication route about thirty-four seconds later,
  taking the chosen input back to the built-in microphone. On that route the
  graph ends at a `MediaStreamAudioDestinationNode` instead, which pulls it
  without opening an output. Everywhere else keeps `ctx.destination`.

## How the app is put together

```
core/ + wasm/            C DSP core, compiled to WebAssembly
web/src/timegrapher/     tg-worker (engine, off-thread), stability, movements, session
web/src/audio/           capture, signal metering, WAV
web/src/components/      one panel each; guide-content.tsx holds every explanation
```

- **The measurement engine runs in a Worker.** It sweeps a sixteen-second window
  through seven FFTs; on the main thread that visibly stutters the UI.
- **The trace is folded and magnified.** A full beat period across the width
  makes a 10 s/day error move two pixels. See `TraceCanvas.tsx`.
- **The beat display's horizontal axis means two things at once.** Milliseconds
  before the beat along the bottom, and the same positions read as amplitude
  along the top — the two are related by `asin(lift angle / 2A) / pi`, which is
  the arithmetic the core uses to measure amplitude in the first place. It lives
  in `timegrapher/amplitude-scale.ts`, not in `BeatCanvas.tsx`, because the
  ruler and the reading have to agree. Solid rules are time, dashed are degrees;
  they share one axis and must not look alike.
- **Device Check is its own settings tab** (`settings/DeviceCheckPanel.tsx`),
  reducing the audio path to a row per question. It adds no audio of its own:
  `readiness.ts` is a pure reducer over facts the app already produces, and
  `device-check.ts` merges those with a finished `runDeviceTest` report. The
  resample/interruption catch is the clock calibrator's own `disturbed` flag — a
  drift too large for any crystal is a starved stream whatever the cause, which
  is what went uncaught the week 44.1 kHz resampled. Device and signal groups are
  separate so "no escapement" never blocks someone still setting up the mic.
  **The live rows count only while a capture is running**: `assessReadiness`
  grades the processing flags "Off" when handed no warnings, which is equally
  true of a clean device and one nothing has listened to, and reading the second
  as the first is the exact failure this panel exists to catch. It is explicitly
  not calibration and says so.
- **Quartz Calibration is its own settings tab** (`settings/QuartzPanel.tsx`),
  not a setting. It needs the microphone and an input chosen, so it carries
  both — it is reachable before the measuring screen has ever asked for
  permission.
- **A non-native sample rate starves the audio clock on iOS.** Measured on one
  iPhone with one USB pickup, minutes apart:

  | context rate | frames/rate vs currentTime | currentTime vs wall |
  |---|---|---|
  | 44,100 Hz | *identical* | -855 to -945 ppm |
  | 48,000 Hz | differ by ~890 ppm | +99 ppm |

  At 44,100 the two carried the same information, so the clock measurement had
  no second reference and reported an impossible figure over two uninterrupted
  runs. At 48,000 — the dongle's native rate — `currentTime` tracks the system
  clock to 99 ppm and the figure is believable. Asking a 48 kHz device for
  44,100 forces a resample that the render thread does not keep up with.
  Suspect the rate before suspecting the crystal.
- **Clock correction is by quartz watch or by hand — the system-clock method
  was removed.** It compared frame delivery against wall time and was the option
  most sensitive to an unstable audio path; on real iOS+USB hardware it never
  produced a usable figure (44.1 kHz resampling, ~2% block rejection). Its
  diagnostic value — is the frame-vs-wall drift absurd — now lives in the device
  check's Audio-timing row, which runs its own `ClockCalibrator` for ten seconds
  and is all that comparison is trustworthy for. Correction is the quartz method
  (`tg_cal_*`, upstream's algorithm) or a figure typed into the field; nothing is
  applied without a press.
- **Lift angle comes from the movement setting**, not a constant. Amplitude is
  calculated directly from it, so a wrong figure is a wrong amplitude — and
  under Auto it is still typed by hand, because nothing in the sound carries it.
  See `timegrapher/movement-choice.ts`.
- **A summary carries averages, never a range.** No positional spread, no lowest
  amplitude, no greatest beat error, on screen or on the document. Each is a
  range over six samples and so the most outlier-sensitive figure a run can
  produce: one knock of the bench during one position moves all three and none
  of the averages. The readings are printed in full; the extremes are readable
  from them and are not presented as a conclusion.
- **`guide-content.tsx` is the single source for every explanation**, read by
  the Guide tab. Do not write help text anywhere else.
- **The v36 interface is the source of truth for layout.** `tokens.css` is that
  design's stylesheet taken across with its cascade intact, overrides and all,
  and the React components reproduce its ids and class names so it could be. Do
  not tidy the cascade by merging blocks: the later rule is the one that was
  signed off. Only the block below the "Added for the React port" line is ours.
  The page scrolls where it needs to; height is no longer a fixed budget every
  addition has to be argued against.
- **`docs/updateui.md` lists what the v36 design left out of the old app** and
  what was deliberately deviated from. Read it before "restoring" anything that
  looks missing; several of those omissions are pending a product decision, not
  bugs.
- **The stability marker fills the settled region rather than moving inside it.**
  While the reading moves it travels and stops with its right edge on the
  boundary — it never sits on green it has not earned. At the verdict it takes
  the region exactly. Locked is a state, not a degree, and both shapes are given
  as concrete left/right offsets so they animate; a width transitioning to
  `auto` snaps. See `timegrapher/stability-position.ts`.
- **An inspection's run is derived from its record**, not kept beside it. The six
  markers come from `resumeWizard(readings)`, so a reload or a trip to the
  opening screen resumes rather than showing an empty panel over stored
  readings. They disagreed once, and the result was a report carrying two
  watches.

## Traps that cost time once already

- **Never use Hostinger's `hosting_deployStaticSiteArchiveV1` or
  `hosting_deployStaticWebsite`.** Both extract into the document root and would
  destroy the PHP app living there; the former's own docs say it "overwrites the
  website's existing contents and cannot be undone". Deploy by per-file TUS
  upload into `tools/timegrapher/`. Full procedure in `docs/deployment.md`.
- **`web/public/capture-worklet.js` is plain JS on purpose.** `addModule` fetches
  a real script; the dev server would hand it untranspiled TypeScript. It must
  stay at the deploy root, not under `assets/`, since it's fetched at runtime
  from `${BASE_URL}capture-worklet.js`.
- **`vite.config.ts` imports `defineConfig` from `'vitest/config'`, not `'vite'`.**
  Vite's own `UserConfig` type has no `test` field and `tsc` rejects it.
- **`tsconfig.app.json` sets `erasableSyntaxOnly: true`.** TypeScript
  parameter-property shorthand (`constructor(readonly x: number)`) fails with
  TS1294. Use explicit fields.
- **Upstream's `.gitignore` opens with a bare `.*`.** New dotfiles under `web/`
  are silently untracked unless negated — this already swallowed
  `web/.oxlintrc.json`.
- **`web/dist/` is never committed**, here or in the private site repo. Compiled
  output of GPL source is GPL-covered; committing it to the private repo would
  reintroduce the entanglement the split exists to avoid.
- **The `upstream` remote has push URL `no_push`** so nothing can be pushed to
  agrigera by accident. Leave it that way.
- **Anything read through `HEAPU8`/`HEAPF32`/`HEAPF64` must be in
  `EXPORTED_RUNTIME_METHODS`** in `wasm/build-wasm.sh`. The worker's TypeScript
  interface declares these, so `tsc` is satisfied by a declaration the build
  never fulfils and every measurement throws at runtime. `tests/compare-wasm-native.mjs`
  exercises the event path for exactly this reason.
- **Service workers do not register in the in-app browser pane.** They work on
  the deployed site. Verify PWA behaviour there, not locally.
- **Settled thresholds in `stability.ts` are measured, not chosen.** They come
  from what a USB pickup on a running NH35 actually holds. Two rounds of this
  have now been got wrong by guessing, so: **rate is the criterion; amplitude
  and beat error are sanity bounds.** Beat error especially — it is a magnitude
  that cannot go below zero and whose noise does not shrink as the true value
  approaches it, so a watch that is *well* in beat reads 0.2, 1.7, 0.7 around
  the resolution floor. Demanding tight stability there blocks exactly the
  watches that deserve to pass, which is what stopped automatic inspections
  recording anything. Rate holding ±0.2 s/day is two parts per million and is
  the real proof the acoustic lock is good.

## Upstream C

`src/` holds upstream's GTK application, untouched and still buildable. It is
not part of the web build; it is the reference implementation the port is
checked against. Native tg has **no WAV file input** (live PortAudio only),
which is why it is kept — a file-input mode gets added there for exact A/B
comparison against a recorded fixture.

`core/` is the extracted DSP (algo + measurement, no GTK/PortAudio/pthread),
built standalone with `make -f Makefile.core` and to WebAssembly with
`wasm/build-wasm.sh`. `fixtures/` is the regression corpus — still empty,
pending a bench recording.

`startCapture` and the React components that touch audio have no automated
tests **by design** — mocking the Web Audio graph would test the mock. They are
verified at the bench. Don't "fix" this by adding mocks.

Components that take only plain props are a different case and *are* tested, as
is every pure module behind them — `stability-position.ts`, `device-check.ts`,
`movement-choice.ts`, `inspection-note.ts` and `export/report.ts` exist as
separate modules precisely so the parts that decide what a person is told, and
what lands on a customer's document, can be driven by a test.

Modal surfaces are the native `<dialog>` element (`Dialog.tsx`), so the browser
supplies the backdrop, the focus trap, Escape and inertness. Keep focus effects
keyed on what actually opened the thing, never on a callback the parent
recreates every render — that bug once made a text field take one character per
tap.

## Commands

```sh
cd web && npm test          # 488 tests across 29 files
cd web && npm run build     # tsc -b && vite build
cd web && npm run dev       # http://localhost:5173/tools/timegrapher/
cd web && npm run dev:lan   # HTTPS on the LAN, for testing on a phone

make -f Makefile.core       # native tg-process (needs brew fftw)
make -f Makefile.core check # synthetic-signal tests
./wasm/build-wasm.sh        # rebuild the WebAssembly core
node tests/compare-wasm-native.mjs FILE.wav   # wasm vs native on one file
./tg-process --waveform FILE.wav              # the averaged beat, as JSON
./tg-process --calibrate QUARTZ.wav           # sound-card clock error from a 1 Hz reference
```

`base` is `/tools/timegrapher/`, overridable via `VITE_BASE` for forks — the dev
URL includes that path.

## Conventions

- It is a **timegrapher** (the instrument). *Regulating* is adjusting the
  movement afterwards. Never call the product a regulator.
- Comments explain *why*, especially where code looks arbitrary — the audio
  constraints, the muted gain node, the stream sink the communication route
  ends at rather than `ctx.destination`. Several
  tests carry comments naming the regression they exist to catch. Keep that.
- Commit messages end with the `Co-Authored-By: Claude Opus 5 <noreply@anthropic.com>` trailer.
