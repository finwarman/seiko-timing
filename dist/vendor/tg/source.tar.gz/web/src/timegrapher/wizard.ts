/*
    MAC Bespoke Web Timegrapher
    Copyright (C) 2026 MAC Bespoke Watch Co.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License version 2 as
    published by the Free Software Foundation.
*/
import { POSITIONS, positionName, type PositionId } from './session';
import type { Settling } from './stability';

/*
   The certification wizard.

   A six-position session is not six measurements; it is six measurements and
   five interruptions. Every time the watch is turned, a hand touches it — and
   that burst of handling noise is indistinguishable, to the analysis, from the
   movement misbehaving. It then sits in the thirty-second window poisoning
   everything measured after it.

   The manual view has a reset button for this, but a button you must remember
   to press is a button that gets forgotten precisely when the session matters.
   So the state machine is shaped around the interruption rather than around
   the measurement: the operator is told to move the watch, presses Go once it
   is settled in place, and only then does the average begin. Audio recorded
   while a hand was on the watch can never reach a reading.
*/

/*
   Dial up, dial down, then the four crown positions in the order a watchmaker
   lists them. This is the v36 design's order and the conventional one; it
   replaces an order chosen so that each step was a single rotation from the
   one before. The two differ only in whether crown up or crown down comes
   third, and the conventional order is what a report is read against.
*/
export const WIZARD_ORDER: PositionId[] = [
  'dial-up',
  'dial-down',
  'crown-up',
  'crown-down',
  'crown-left',
  'crown-right',
];

export type WizardStage =
  /** Waiting for the operator to place the watch and press Start. */
  | 'prompt'
  /** Audio is running but nothing is being kept yet — the get-clear grace. */
  | 'countdown'
  /** The average has been restarted and is building. */
  | 'measuring'
  /** A reading was just recorded; showing it before moving on. */
  | 'captured'
  /** Every position in the run has been dealt with. */
  | 'done';

export interface WizardState {
  /** Index into WIZARD_ORDER. Equals its length once finished. */
  step: number;
  stage: WizardStage;
  /** Positions recorded by this run, for the closing summary. */
  recorded: PositionId[];
}

/**
 * Consecutive settled reports required before an unattended capture fires.
 *
 * `settling()` is already conservative — thirty seconds of history, twenty
 * seconds minimum — but it is evaluated twice a second, and a reading can
 * graze the bounds for a single report on its way through. Requiring the state
 * to hold costs half a second and removes that.
 */
export const AUTO_CAPTURE_CONFIRMATIONS = 2;

/**
 * Seconds of measuring after which the wizard stops promising it will settle.
 *
 * It does not capture anyway — it says so and hands the decision back. A watch
 * that will not settle is telling you something, and burying that under an
 * automatic capture would put the noise on a certificate.
 */
export const STALL_SECONDS = 75;

export function startWizard(): WizardState {
  return { step: 0, stage: 'prompt', recorded: [] };
}

/**
 * A run rebuilt from the readings already on the record.
 *
 * The markers and the report have to agree. They are drawn from different
 * places — the markers from this state, the report from the stored inspection —
 * and when a reload or a trip to the opening screen reset one and not the other,
 * the panel said nothing had been captured while the report held six readings
 * from the watch before. Printing that produced a certificate mixing two
 * watches.
 *
 * So the run is derived from the record rather than kept beside it, and lands on
 * the first position that has not been measured.
 */
export function resumeWizard(recorded: PositionId[]): WizardState {
  const kept = WIZARD_ORDER.filter((p) => recorded.includes(p));
  const next = WIZARD_ORDER.findIndex((p) => !kept.includes(p));
  return {
    step: next === -1 ? WIZARD_ORDER.length : next,
    stage: next === -1 ? 'done' : 'prompt',
    recorded: kept,
  };
}

/** The position a step measures, or null once the run is past the end. */
export function positionAt(step: number): PositionId | null {
  return WIZARD_ORDER[step] ?? null;
}

/** Human label for the current step, e.g. "Position 3 of 6 — Crown down". */
export function stepLabel(state: WizardState): string {
  const position = positionAt(state.step);
  if (!position) return 'Finished';
  return `Position ${state.step + 1} of ${WIZARD_ORDER.length} — ${positionName(position)}`;
}

/**
 * Seconds between pressing Start and the reading beginning to count.
 *
 * The operator's hand is on the watch when they reach for Start, and letting go
 * of it is itself a noise. Three seconds is long enough to withdraw and for the
 * bench to stop ringing, and short enough not to feel like waiting.
 */
export const COUNTDOWN_SECONDS = 3;

/** Start pressed: audio is running, but nothing counts until the grace ends. */
export function begin(state: WizardState): WizardState {
  if (state.stage !== 'prompt') return state;
  return { ...state, stage: 'countdown' };
}

/** The grace elapsed. The caller restarts the average as it calls this. */
export function armed(state: WizardState): WizardState {
  if (state.stage !== 'countdown') return state;
  return { ...state, stage: 'measuring' };
}

/**
 * Stop pressed, or capture lost, before a reading was recorded. Back to the
 * same position — nothing was kept, so there is nothing to move on from.
 */
export function abort(state: WizardState): WizardState {
  if (state.stage !== 'countdown' && state.stage !== 'measuring') return state;
  return { ...state, stage: 'prompt' };
}

/** A reading was recorded for the current position. */
export function captured(state: WizardState): WizardState {
  const position = positionAt(state.step);
  if (state.stage !== 'measuring' || !position) return state;
  return {
    ...state,
    stage: 'captured',
    recorded: state.recorded.includes(position) ? state.recorded : [...state.recorded, position],
  };
}

/**
 * Move to the next position that has not been recorded.
 *
 * The next *uncaptured* one, not simply the next index: a position measured out
 * of order — or re-measured — must not send the run back over ground it has
 * already covered. With a straight run through the six they are the same thing.
 */
export function advance(state: WizardState): WizardState {
  for (let step = state.step + 1; step < WIZARD_ORDER.length; step++) {
    if (!state.recorded.includes(WIZARD_ORDER[step])) {
      return { ...state, step, stage: 'prompt' };
    }
  }
  /* Nothing left after this one. Anything skipped earlier is picked up here, so
     the run only reports itself finished when there is genuinely nothing left. */
  const earlier = WIZARD_ORDER.findIndex((p) => !state.recorded.includes(p));
  if (earlier >= 0) return { ...state, step: earlier, stage: 'prompt' };
  return { ...state, step: WIZARD_ORDER.length, stage: 'done' };
}

/** Stop early, keeping whatever has been recorded. */
export function finish(state: WizardState): WizardState {
  return { ...state, step: WIZARD_ORDER.length, stage: 'done' };
}

/** Re-measure the position just captured rather than moving on. */
export function retry(state: WizardState): WizardState {
  if (state.stage !== 'captured') return state;
  return { ...state, stage: 'prompt' };
}

/**
 * Whether an unattended capture should fire now.
 *
 * Every condition has to hold: the run is measuring, the operator asked for
 * automatic capture, the core produced a usable reading, and the reading has
 * been settled for long enough to trust.
 */
export function shouldAutoCapture(opts: {
  stage: WizardStage;
  auto: boolean;
  valid: boolean;
  settling: Settling;
  settledRuns: number;
}): boolean {
  return (
    opts.stage === 'measuring' &&
    opts.auto &&
    opts.valid &&
    opts.settling === 'settled' &&
    opts.settledRuns >= AUTO_CAPTURE_CONFIRMATIONS
  );
}

/** True once the reading has been unsettled for long enough to say so. */
export function hasStalled(stage: WizardStage, settling: Settling, seconds: number): boolean {
  return stage === 'measuring' && settling !== 'settled' && seconds >= STALL_SECONDS;
}

/** Positions in the run that were stepped past without a reading. */
export function skipped(state: WizardState): PositionId[] {
  return WIZARD_ORDER.slice(0, state.step).filter((p) => !state.recorded.includes(p));
}

/* Every wizard position must exist in the session's position list, or a
   recorded reading would land somewhere the summary never reads it. */
export function orderIsValid(): boolean {
  const known = new Set(POSITIONS.map((p) => p.id as PositionId));
  return (
    WIZARD_ORDER.length === POSITIONS.length && WIZARD_ORDER.every((p) => known.has(p))
  );
}

const AUTO_KEY = 'mac-timegrapher.auto-capture';

/**
 * Automatic capture defaults on. It is the reason the wizard exists — with it
 * off, the operator still has to reach for the screen between every position,
 * which is the handling the run is built to avoid.
 */
export function loadAutoCapture(): boolean {
  try {
    return localStorage.getItem(AUTO_KEY) !== 'off';
  } catch {
    return true;
  }
}

export function saveAutoCapture(auto: boolean): void {
  try {
    localStorage.setItem(AUTO_KEY, auto ? 'on' : 'off');
  } catch {
    // Private browsing or a full quota; a forgotten preference is not worth
    // failing over.
  }
}

/** Jump straight to a position — re-measuring one without re-running the set. */
export function jumpTo(state: WizardState, step: number): WizardState {
  if (step < 0 || step >= WIZARD_ORDER.length) return state;
  return { ...state, step, stage: 'prompt' };
}
